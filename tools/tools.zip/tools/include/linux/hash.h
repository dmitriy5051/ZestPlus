#include "../../../include/linux/hash.h"

#ifndef _TOOLS_LINUX_HASH_H
#define _TOOLS_LINUX_HASH_H
#endif
