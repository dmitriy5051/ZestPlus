#include <slang.h>

int main(void)
{
	return SLsmg_init_smg();
}
