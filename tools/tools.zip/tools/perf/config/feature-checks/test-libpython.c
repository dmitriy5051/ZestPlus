#include <Python.h>

int main(void)
{
	Py_Initialize();

	return 0;
}
