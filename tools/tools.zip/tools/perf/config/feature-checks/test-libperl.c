#include <EXTERN.h>
#include <perl.h>

int main(void)
{
	perl_alloc();

	return 0;
}
