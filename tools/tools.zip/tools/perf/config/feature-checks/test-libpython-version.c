#include <Python.h>

#if PY_VERSION_HEX >= 0x03000000
	#error
#endif

int main(void)
{
	return 0;
}
