#include <numa.h>
#include <numaif.h>

int main(void)
{
	numa_available();

	return 0;
}
