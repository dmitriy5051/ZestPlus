#include <android/api-level.h>

int main(void)
{
	return __ANDROID_API__;
}
