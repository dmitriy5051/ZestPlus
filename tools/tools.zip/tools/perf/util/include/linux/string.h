#include <string.h>

void *memdup(const void *src, size_t len);
