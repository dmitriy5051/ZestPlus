#ifndef __ASM_GENERIC_HASH_H
#define __ASM_GENERIC_HASH_H

/* Stub */

#endif /* __ASM_GENERIC_HASH_H */
