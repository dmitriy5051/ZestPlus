#ifndef _LIBLOCKDEP_LINUX_COMPILER_H_
#define _LIBLOCKDEP_LINUX_COMPILER_H_

#define __used		__attribute__((__unused__))
#define unlikely

#endif
