#define __always_inline
#include "../../../include/linux/rbtree_augmented.h"
