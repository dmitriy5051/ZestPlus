#ifndef _LIBLOCKDEP_LINUX_STRINGIFY_H_
#define _LIBLOCKDEP_LINUX_STRINGIFY_H_

#define __stringify_1(x...)	#x
#define __stringify(x...)	__stringify_1(x)

#endif
