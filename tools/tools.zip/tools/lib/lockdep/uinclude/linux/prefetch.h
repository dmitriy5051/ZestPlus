#ifndef _LIBLOCKDEP_LINUX_PREFETCH_H_
#define _LIBLOCKDEP_LINUX_PREFETCH_H

static inline void prefetch(void *a __attribute__((unused))) { }

#endif
