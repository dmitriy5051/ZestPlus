#ifndef _LIBLOCKDEP_LINUX_KMEMCHECK_H_
#define _LIBLOCKDEP_LINUX_KMEMCHECK_H_

static inline void kmemcheck_mark_initialized(void *address, unsigned int n)
{
}

#endif
